package sapphiros;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import objectrepository.Loginpage;



public class Base {

	public  WebDriver driver;
	public Properties prop;
public WebDriver initializeDriver() throws IOException
{
	
 prop= new Properties();
FileInputStream fis=new FileInputStream("//Users//prince//Documents//workspace//Internaladmin//src//main//java//sapphiros//Data.properties");

prop.load(fis);
String browserName=prop.getProperty("browser");
System.out.println(browserName);

if(browserName.equals("chrome"))
{
	 System.setProperty("webdriver.chrome.driver", "//Users//prince//Downloads//Seaport content//Selenium//chromedriver");
	driver= new ChromeDriver();
		//execute in chrome driver
	
}
else if (browserName.equals("firefox"))
{
	 driver= new FirefoxDriver();
	//firefox code
}
else if (browserName.equals("IE"))
{
//	IE code
}

if (driver == null) {
	 getInstance(browserName);
	
	driver.manage().window().maximize();
driver.get("https://preproduction.telomerediagnostics.com/");
} else {

	
	driver.manage().window().maximize();
driver.get("https://preproduction.telomerediagnostics.com/");
}


driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
return driver;
}
private void getInstance(String browserName) {
	// TODO Auto-generated method stub
	
}
}
