package internaladmin;


import org.testng.annotations.BeforeTest;
import java.io.IOException;

import objectrepository.Loginpage;
import sapphiros.Base;

public class Logintest extends Base {
	@BeforeTest
	  public void basePageNavigation() throws IOException
	{
		driver=initializeDriver();
		Loginpage l=new Loginpage(driver);
		l.EmailId().sendKeys("prince.cl@calpinetech.com");
		l.Password().sendKeys("calpine123");
		l.Submit().click();
	}

}

