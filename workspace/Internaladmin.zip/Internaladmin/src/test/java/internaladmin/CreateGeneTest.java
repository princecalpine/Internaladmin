package internaladmin;

import java.io.IOException;

import org.testng.annotations.Test;

import objectrepository.CreateGene;
import sapphiros.Base;

public class CreateGeneTest extends Base {
	@Test
	public void CreateGene() throws IOException
	{  
		//driver=initializeDriver();
		CreateGene Cg=new CreateGene(driver);
		Cg.PGVmodule().click();
		Cg.PGVimage().click();
	}


}
